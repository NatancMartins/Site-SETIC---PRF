import {sqlite3} from 'sqlite3';
import { open } from 'sqlite';

function criarTabelaSetor(){
    
}